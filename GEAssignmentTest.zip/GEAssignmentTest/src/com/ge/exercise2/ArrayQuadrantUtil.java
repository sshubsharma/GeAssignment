package com.ge.exercise2;
import java.util.Scanner;

public class ArrayQuadrantUtil{ 
	public void convert(Object[][] arr,int r,int c) { 
		System.out.print("Operation #1 for row 0 ");
		for (int i = 0; i < 1; i++) { 
			 //printing the row
				for (int j = 0; j < c; j++) { 
					System.out.print(" " + arr[i][j]); 
				} 
			} 
		System.out.println();
		System.out.print("Operation #2 for column 0 ");
		//printing the column
		for (int i = 0; i < r; i++) { 
				for (int j = 0; j < 1; j++) { 
					System.out.print(" " + arr[i][j]); 
				} 
			} 
		//printing the value for [0,0]quadrant 
		System.out.println();
		System.out.print("Operation #3 for quadrant 0,0 ");
		for (int i = 0; i < r; i++) { 
			for (int j = 0; j < c; j++) { 
				if((i==0 || i==1) && (j==0 || j==1)) {
					System.out.print(" " + arr[i][j]);
				}
			} 
		} 
	} 

	//Driver Code
	static public void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("kindly provide the number of row");
		int r=sc.nextInt();   
		System.out.println("kindly provide the number of column");
		int c=sc.nextInt(); 
		
		Object arr[][]=new Object[r][c];
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				arr[i][j]=sc.next();
			}
			
		}
		ArrayQuadrantUtil aq=new ArrayQuadrantUtil();
		aq.convert(arr,r,c); 
	} 
} 

