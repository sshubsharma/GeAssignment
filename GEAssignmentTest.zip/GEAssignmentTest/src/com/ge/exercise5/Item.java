package com.ge.exercise5;

public class Item {
	
	private int itemid;
	private String name;
	private String typeofitem;
	private int value;
	private int sellby;
	private int normalrate;
	
	public Item(int itemid, String name, String typeofitem, int value, int sellby, int normalrate) {
		super();
		this.itemid=itemid;
		this.name=name;
		this.typeofitem=typeofitem;
		this.value=value;
		this.sellby=sellby;
		this.normalrate=normalrate;
	}
	public Item() {
		// TODO Auto-generated constructor stub
	}
	public int getNormalrate() {
		return normalrate;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public void setNormalrate(int normalrate) {
		this.normalrate = normalrate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTypeofitem() {
		return typeofitem;
	}
	public void setTypeofitem(String typeofitem) {
		this.typeofitem = typeofitem;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getSellby() {
		return sellby;
	}
	public void setSellby(int sellby) {
		this.sellby = sellby;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + normalrate;
		result = prime * result + sellby;
		result = prime * result + ((typeofitem == null) ? 0 : typeofitem.hashCode());
		result = prime * result + value;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (normalrate != other.normalrate)
			return false;
		if (sellby != other.sellby)
			return false;
		if (typeofitem == null) {
			if (other.typeofitem != null)
				return false;
		} else if (!typeofitem.equals(other.typeofitem))
			return false;
		if (value != other.value)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Item [itemid=" + itemid + ", name=" + name + ", typeofitem=" + typeofitem + ", value=" + value
				+ ", sellby=" + sellby + ", normalrate=" + normalrate + "]";
	}
	
}
