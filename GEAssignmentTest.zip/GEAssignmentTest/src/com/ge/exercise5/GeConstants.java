package com.ge.exercise5;

public class GeConstants {
	
	public static final String ge_item_perishable= "perishable";
	public static Object ge_item_normal="normal";
}
