package com.ge.exercise5;

import java.util.ArrayList;
import java.util.List;

abstract class Warehouse{
	/*abstract method updateItems
	 * this method will change according to
	 * the item class.
	 */
	abstract void updateItems() ;
}

public class WarehouseTest extends Warehouse{
	private Item item=new Item();
	
	//preparing the static list for testing
	public static List<Item> itemlst=new ArrayList<Item>();
	static {
		//Once the sell by date has passed-->setting sellby value 0
		itemlst.add(new Item(1,"mobile","normal",10,0,30));
		//Perishable item
		itemlst.add(new Item(2,"mango","perishable",11,11,15));
	}
	
	@Override
	 void updateItems() {
		
		//calculating the down in value for normal item
		int valuedown=0;
		for(Item items : itemlst) {
			if(null!=items.getTypeofitem() && items.getTypeofitem().equals(GeConstants.ge_item_normal)) {
				if(items.getSellby()==0 || items.getSellby()<0) {
					if(items.getValue()!=0) {
						valuedown=items.getValue()-(2*(items.getNormalrate()));
						item.setValue(valuedown);
						System.out.println("Once the sell by date has passed, value goes down at twice the normal rate " + item.getValue());
					}
				 }
			}
			
			//	Perishable items are to degrade in value twice as fast as normal items
			if(null!=items.getTypeofitem() && items.getTypeofitem().equals(GeConstants.ge_item_perishable)) {
				item.setValue(2*valuedown);
				System.out.println("Perishable items are to degrade in value twice as fast as normal items " + item.getValue());
				}
		   }

		}
	
		public static void main(String[] args) {
		WarehouseTest warehouseTest=new WarehouseTest();
		warehouseTest.updateItems();
		}
	}

